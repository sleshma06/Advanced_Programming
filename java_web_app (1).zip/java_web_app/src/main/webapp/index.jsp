<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise Java | MVC Architecture</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --secondary: #64748b;
            --dark: #0f172a;
            --light: #f8fafc;
            --glass: rgba(255, 255, 255, 0.8);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: radial-gradient(circle at top right, #e2e8f0, #ffffff);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
        }

        /* Navigation */
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.5rem 10%;
            background: var(--glass);
            backdrop-filter: blur(10px);
            position: sticky;
            top: 0;
            z-index: 1000;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }

        .logo { font-weight: 800; font-size: 1.4rem; color: var(--primary); letter-spacing: -1px; }

        .nav-links { list-style: none; display: flex; gap: 2rem; }

        .nav-links a {
            text-decoration: none;
            color: var(--secondary);
            font-weight: 500;
            font-size: 0.9rem;
            transition: color 0.3s;
        }

        .nav-links a:hover { color: var(--primary); }

        /* Hero Section */
        .hero {
            padding: 100px 10% 60px;
            text-align: center;
            max-width: 900px;
            margin: 0 auto;
        }

        .hero h1 {
            font-size: 3.5rem;
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 1.5rem;
            background: linear-gradient(to right, #1e293b, #2563eb);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero p {
            font-size: 1.2rem;
            color: var(--secondary);
            margin-bottom: 2.5rem;
        }

        /* Action Buttons */
        .cta-group { display: flex; gap: 1rem; justify-content: center; }

        .btn {
            padding: 0.8rem 2rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary { background: var(--primary); color: white; box-shadow: 0 10px 15px -3px rgba(37, 99, 235, 0.3); }
        .btn-primary:hover { transform: translateY(-2px); background: #1d4ed8; }

        .btn-secondary { background: white; color: var(--dark); border: 1px solid #e2e8f0; }
        .btn-secondary:hover { background: #f1f5f9; }

        /* Features Grid (The "Informative" part) */
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            padding: 4rem 10%;
        }

        .card {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            border: 1px solid #f1f5f9;
            transition: border-color 0.3s;
        }

        .card:hover { border-color: var(--primary); }

        .card h3 { margin-bottom: 0.8rem; font-size: 1.1rem; }

        .card p { font-size: 0.9rem; color: var(--secondary); }

        footer {
            text-align: center;
            padding: 4rem 0;
            font-size: 0.8rem;
            color: #94a3b8;
        }
    </style>
</head>
<body>

    <nav>
        <div class="logo">JAVA_WEB</div>
        <ul class="nav-links">
            <li><a href="${pageContext.request.contextPath}/home">Home</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Contact</a></li>
            <li><a href="${pageContext.request.contextPath}/login">Sign In</a></li>
        </ul>
    </nav>

    <main>
        <section class="hero">
            <h1>Scalable Web Apps with MVC Architecture</h1>
            <p>Deploy robust enterprise solutions using JSP, Servlets, and DAO. Built for performance, designed for clarity.</p>
            
            <div class="cta-group">
                <a href="${pageContext.request.contextPath}/register" class="btn btn-primary">Create Account</a>
                <a href="${pageContext.request.contextPath}/login" class="btn btn-secondary">System Login</a>
            </div>
        </section>

        <section class="features">
            <div class="card">
                <h3>Servlet Controller</h3>
                <p>Centralized request handling to manage application flow and business logic efficiently.</p>
            </div>
            <div class="card">
                <h3>JSP Views</h3>
                <p>Decoupled presentation layer using dynamic templates for a seamless user experience.</p>
            </div>
            <div class="card">
                <h3>DAO Pattern</h3>
                <p>Abstract data persistence logic to maintain clean code and database independence.</p>
            </div>
        </section>
    </main>

    <footer>
        &copy; 2026 MVC Web Framework. Built with Java EE.
    </footer>

</body>
</html>