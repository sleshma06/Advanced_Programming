<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard | ${user.firstName}</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/dashboard.css">

    <style>
        .avatar-circle {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: #eef2ff;
            color: #4f46e5;
            font-weight: 700;
            border: 1px solid #e0e7ff;
            text-transform: uppercase;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>

    <nav class="sidebar">
        <div class="sidebar-header">
            STUDENT<span>HUB</span>
        </div>
        <a href="#" class="nav-item active">
            <i class="fas fa-th-large"></i> Dashboard
        </a>
        <a href="#" class="nav-item">
            <i class="fas fa-graduation-cap"></i> Academics
        </a>
        <a href="profile" class="nav-item">
            <i class="fas fa-user-edit"></i> Edit Profile
        </a>
        <a href="${pageContext.request.contextPath}/logout" class="nav-item logout-btn">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </nav>

    <div class="main-content">
        <header>
            <div class="breadcrumb">Overview / <strong>Dashboard</strong></div>
            <div class="user-profile-header">
                <span class="info-value" style="font-size: 0.9rem; margin-right: 15px;">${user.email}</span>
                <div class="avatar-circle">
                    <img src="${pageContext.request.contextPath}/getimage?name=${user.userName}" 
                         alt="Profile_Image" 
                         style="width: 100%; height: 100%; object-fit: cover;"
                         onerror="handleProfileImageError(this, '${user.userName}', '${user.firstName.substring(0,1)}${user.lastName.substring(0,1)}')">
                </div>
            </div>
        </header>

        <div class="container">
            <div class="welcome-banner">
                <h1>Hello, ${user.firstName}!</h1>
                <p>Welcome back to your creative learning space. Here is your current status.</p>
            </div>

            <div class="grid">
                <div class="card">
                    <div class="card-title">
                        <i class="fas fa-id-badge"></i> Account Info
                    </div>
                    <div class="info-group">
                        <div class="info-label">Username</div>
                        <div class="info-value">@${user.userName}</div>
                    </div>
                    <div class="info-group">
                        <div class="info-label">Program</div>
                        <div class="info-value">
                            <c:choose>
                                <c:when test="${user.program == 2}"><span class="badge">Bachelors in Computing</span></c:when>
                                <c:when test="${user.program == 5}"><span class="badge">Bachelors in Multimedia</span></c:when>
                                <c:when test="${user.program == 6}"><span class="badge">Bachelors in Networking</span></c:when>
                                <c:otherwise>General Studies</c:otherwise>
                            </c:choose>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-title">
                        <i class="fas fa-envelope-open-text"></i> Contact
                    </div>
                    <div class="info-group">
                        <div class="info-label">Email Address</div>
                        <div class="info-value">${user.email}</div>
                    </div>
                    <div class="info-group">
                        <div class="info-label">Phone</div>
                        <div class="info-value">${user.number}</div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-title">
                        <i class="fas fa-user-check"></i> Profile
                    </div>
                    <div class="info-group">
                        <div class="info-label">Birthday</div>
                        <div class="info-value"><fmt:formatDate value="${user.dob}" pattern="dd MMM, yyyy" /></div>
                    </div>
                    <div class="info-group">
                        <div class="info-label">Gender</div>
                        <div class="info-value" style="text-transform: capitalize;">${user.gender}</div>
                    </div>
                    <div class="info-group">
                        <div class="info-label">Your last login was:</div>
                        <div class="info-value">
                            <c:out value="${cookie.last_login.value != null ? cookie.last_login.value : 'Cookie Not Found'}" />
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </div>

</body>
</html>