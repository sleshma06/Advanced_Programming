<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Account</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/login.css">
    
    <style>
        /* Error Alert Styling */
        .error-container {
            background: #fff1f2;
            border: 1px solid #fecdd3;
            color: #e11d48;
            padding: 0.75rem 1rem;
            border-radius: 10px;
            font-size: 0.85rem;
            margin-bottom: 1.25rem;
            display: flex;
            align-items: center;
            gap: 10px;
            /* Entrance animation */
            animation: fadeIn 0.3s ease forwards;
            /* Preparation for exit transition */
            transition: opacity 0.5s ease, transform 0.5s ease, margin 0.5s ease;
            overflow: hidden;
        }

        /* Class to be added by JS after 5 seconds */
        .fade-out {
            opacity: 0;
            transform: translateY(-10px);
            margin-bottom: 0;
            padding-top: 0;
            padding-bottom: 0;
            height: 0;
            border: 0;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-5px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<div class="layout">
    <div class="left-panel">
        <div class="left-inner">
            <h1 class="title">Sign <span>In</span></h1>
            <p class="tagline">Welcome back to our creative learning space.</p>
        </div>
    </div>

    <div class="right-panel">
        <div class="form-card">
            <h2>Login to Your Account</h2>
            <p class="subtitle">Enter your credentials to continue</p>

            <%-- Added id="errorPopup" for JavaScript targeting --%>
            <c:if test="${not empty error}">
                <div id="errorPopup" class="error-container">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span>${error}</span>
                </div>
            </c:if>

            <form action="${pageContext.request.contextPath}/login" method="post">
                <div class="field">
                    <label>Username</label>
                    <div class="input-wrap">
                        <i class="fa fa-user-circle"></i>
                        <input type="text" name="username" placeholder="johndoe" value="${typedUser}">
                    </div>
                </div>

                <div class="field">
                    <label>Password</label>
                    <div class="input-wrap">
                        <i class="fa fa-lock"></i>
                        <input type="password" name="password" placeholder="••••••••">
                    </div>
                </div>

                <button class="submit-btn" type="submit">
                    Login <i class="fa fa-arrow-right"></i>
                </button>
            </form>
            
            <div class="footer-text">
                Don't have an account? <a href="${pageContext.request.contextPath}/register">Sign Up</a>
            </div>
        </div>
    </div>
</div>

<script>
    // Execute when the page is fully loaded
    document.addEventListener('DOMContentLoaded', function() {
        const errorPopup = document.getElementById('errorPopup');
        
        if (errorPopup) {
            // Wait for 5 seconds (5000ms)
            setTimeout(() => {
                // Add the fade-out class to trigger CSS transitions
                errorPopup.classList.add('fade-out');
                
                // Optional: Remove from DOM entirely after transition finishes (500ms later)
                setTimeout(() => {
                    errorPopup.remove();
                }, 500);
            }, 5000);
        }
    });
</script>

</body>
</html>