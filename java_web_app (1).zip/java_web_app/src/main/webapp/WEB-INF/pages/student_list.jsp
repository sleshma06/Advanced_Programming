<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Directory</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/css/student_list.css">
    
    <style>
        .user-flex { display: flex; align-items: center; gap: 12px; }
        .avatar-circle {
            width: 40px; height: 40px; border-radius: 50%;
            background: #eef2ff; color: #4f46e5;
            font-weight: 700; font-size: 0.8rem;
            flex-shrink: 0; border: 1px solid #e0e7ff;
            text-transform: uppercase;
            overflow: hidden; display: flex;
            align-items: center; justify-content: center;
        }
        .user-info { display: flex; flex-direction: column; }
        .program-tag { 
            padding: 4px 10px; border-radius: 20px; 
            font-size: 0.75rem; font-weight: 600; background: #f3f4f6; 
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header-flex">
        <h2>Student <span>Directory</span></h2>
        <c:if test="${not empty students}">
            <div class="stats-badge">
                <i class="fa fa-graduation-cap"></i> &nbsp; ${fn:length(students)} Enrolled
            </div>
        </c:if>
    </div>

    <div class="table-card">
        <c:choose>
            <c:when test="${empty students}">
                <div class="empty-state">
                    <i class="fa-regular fa-folder-open fa-3x" style="margin-bottom: 1rem; opacity: 0.5;"></i>
                    <p>No student records found.</p>
                </div>
            </c:when>
            
            <c:otherwise>
                <table>
                    <thead>
                        <tr>
                            <th>Student Details</th>
                            <th>Email Address</th>
                            <th>Date of Birth</th>
                            <th>Enrolled Program</th>
                            <th>Permission</th>
                            <th style="text-align: right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="s" items="${students}">
                            <tr>
                                <td>
                                    <div class="user-flex">
                                        <div class="avatar-circle">
                                            <%-- Start with PNG as default --%>
                                            <img src="${pageContext.request.contextPath}/getimage?name=${s.userName}" 
                                                 alt="Profile" 
                                                 style="width: 100%; height: 100%; object-fit: cover;"
                                                 onerror="handleImageError(this, '${s.userName}', '${fn:substring(s.firstName, 0, 1)}${fn:substring(s.lastName, 0, 1)}')">
                                        </div>
                                        
                                        <div class="user-info">
                                            <span class="user-name">${s.firstName} ${s.lastName}</span>
                                            <span class="user-handle">@${fn:toLowerCase(s.userName)}</span>
                                        </div>
                                    </div>
                                </td>
                                <td>${s.email}</td>
                                <td>
                                    <fmt:formatDate value="${s.dob}" pattern="dd MMM, yyyy" />
                                </td>
                                <td>
                                    <span class="program-tag">
                                        <c:choose>
                                            <c:when test="${s.program == 2}">Bachelors in Computing</c:when>
                                            <c:when test="${s.program == 5}">Bachelors in Multimedia</c:when>
                                            <c:when test="${s.program == 6}">Bachelors in Networking</c:when>
                                            <c:otherwise>General Studies</c:otherwise>
                                        </c:choose>
                                    </span>
                                </td>
                                <td>
                                    <span class="program-tag">
                                        <c:choose>
                                            <c:when test="${s.program == 2}">Can DELETE</c:when>
                                            <c:when test="${s.program == 5}">Can VIEW</c:when>
                                            <c:when test="${s.program == 6}">Can EDIT</c:when>
                                            <c:otherwise>Restricted</c:otherwise>
                                        </c:choose>
                                    </span>
                                </td>
                                <td style="text-align: right;">
                                    <a href="edit?user=${s.userName}" class="edit-btn">
                                        <i class="fa fa-pen-to-square"></i> Edit
                                    </a>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </c:otherwise>
        </c:choose>
    </div>
</div>

</body>
</html>