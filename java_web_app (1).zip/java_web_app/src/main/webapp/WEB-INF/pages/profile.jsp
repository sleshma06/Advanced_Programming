<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile | StudentHub</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary: #4a90e2;
            --sidebar-dark: #1e293b;
            --bg-light: #f8fafc;
            --text-main: #334155;
            --success: #10b981;
            --error: #ef4444;
            --border: #e2e8f0;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-light);
            background-image: radial-gradient(at 0% 0%, rgba(74, 144, 226, 0.05) 0px, transparent 50%), 
                              radial-gradient(at 100% 0%, rgba(74, 144, 226, 0.05) 0px, transparent 50%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px; /* Space for mobile */
        }

        .upload-card {
            background: white;
            padding: 2.5rem;
            border-radius: 20px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.05), 0 10px 10px -5px rgba(0, 0, 0, 0.02);
            width: 100%;
            max-width: 480px; /* Slightly wider to accommodate fields */
            text-align: center;
            border: 1px solid rgba(226, 232, 240, 0.8);
        }

        h2 {
            color: var(--sidebar-dark);
            font-weight: 700;
            margin-bottom: 0.5rem;
            letter-spacing: -0.5px;
        }

        .subtitle {
            color: #64748b;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
        }

        /* Alerts */
        .alert {
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            font-size: 0.85rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .alert-success { background: #ecfdf5; color: var(--success); border: 1px solid #d1fae5; }
        .alert-error { background: #fef2f2; color: var(--error); border: 1px solid #fee2e2; }

        /* Image Preview Area */
        .preview-container {
            width: 110px;
            height: 110px;
            margin: 0 auto 1.2rem;
            border-radius: 50%;
            border: 3px solid #f1f5f9;
            overflow: hidden;
            background: #f8fafc;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        #imagePreview {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: none;
        }

        .preview-placeholder {
            color: #cbd5e1;
            font-size: 2.2rem;
        }

        /* Input Group Styling */
        .input-group {
            text-align: left;
            margin-bottom: 1.2rem;
        }

        .input-group label {
            display: block;
            font-size: 0.85rem;
            font-weight: 600;
            color: #64748b;
            margin-bottom: 6px;
            margin-left: 4px;
        }

        .input-group input {
            width: 100%;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid var(--border);
            font-family: inherit;
            font-size: 0.95rem;
            color: var(--text-main);
            box-sizing: border-box;
            transition: all 0.2s;
            background: #fcfdfe;
        }

        .input-group input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(74, 144, 226, 0.1);
            background: white;
        }

        /* File Input Styling */
        .file-input-wrapper {
            margin-bottom: 2rem;
        }

        input[type="file"] {
            display: none;
        }

        .custom-file-upload {
            display: inline-block;
            padding: 10px 15px;
            cursor: pointer;
            background: #f1f5f9;
            border-radius: 10px;
            color: var(--text-main);
            font-weight: 500;
            font-size: 0.85rem;
            transition: all 0.2s;
            border: 1px solid #e2e8f0;
            width: 100%;
            box-sizing: border-box;
        }

        .custom-file-upload:hover {
            background: #e2e8f0;
        }

        .btn-submit {
            background-color: var(--primary);
            color: white;
            border: none;
            padding: 14px;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            transition: transform 0.2s, background 0.2s;
            box-shadow: 0 4px 14px 0 rgba(74, 144, 226, 0.39);
        }

        .btn-submit:hover {
            background-color: #357abd;
            transform: translateY(-1px);
        }

        .back-link {
            display: inline-block;
            margin-top: 1.5rem;
            color: #64748b;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            transition: color 0.2s;
        }

        .back-link:hover {
            color: var(--primary);
        }
    </style>
</head>
<body>

    <div class="upload-card">
        <h2>Update Profile</h2>
        <p class="subtitle">Personalize your student account</p>

        <c:if test="${not empty message}">
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> ${message}
            </div>
        </c:if>
        <c:if test="${not empty error}">
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> ${error}
            </div>
        </c:if>

        <form action="profile" method="post" enctype="multipart/form-data">
            
            <div class="preview-container">
                <i class="fas fa-user preview-placeholder" id="placeholderIcon"></i>
                <img id="imagePreview" src="#" alt="Preview">
            </div>

            <div class="file-input-wrapper">
                <label for="profileImage" class="custom-file-upload">
                    <i class="fas fa-camera"></i> Change Photo
                </label>
                <input type="file" id="profileImage" name="profileImage" 
                       accept="image/*" onchange="previewFile()">
            </div>

            <div class="input-group">
                <label>First Name</label>
                <input type="text" name="firstName" value="${user.firstName}" required>
            </div>
            
            // Similar to First Name, add other fields Last Name, Date of Birth, Email Address, Phone Number
            // Use value attribute in each input tag to pre-fill user information in respective fields

                        
            <button type="submit" class="btn-submit">Save Changes</button>
        </form>

        <a href="${pageContext.request.contextPath}/dashboard" class="back-link">
            <i class="fas fa-arrow-left"></i> Go to Dashboard
        </a>
    </div>

    <script>
        function previewFile() {
            const preview = document.getElementById('imagePreview');
            const file = document.querySelector('input[name=profileImage]').files[0];
            const reader = new FileReader();
            const placeholder = document.getElementById('placeholderIcon');

            reader.onloadend = function () {
                preview.src = reader.result;
                preview.style.display = 'block';
                placeholder.style.display = 'none';
            }

            if (file) {
                reader.readAsDataURL(file);
            }
        }
    </script>

</body>
</html>
