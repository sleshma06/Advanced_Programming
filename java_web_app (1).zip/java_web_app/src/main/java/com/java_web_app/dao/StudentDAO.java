package com.java_web_app.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.java_web_app.model.StudentModel;
import com.java_web_app.utils.DBconfig;

public class StudentDAO {

    public void insertStudent(String firstName, String lastName, String username, String dob,
                              String gender, String email, String number, String password, int programId) throws Exception {

        LocalDate localDate = LocalDate.parse(dob); 
        Date sqlDate = Date.valueOf(localDate);

        Connection con = DBconfig.getConnection();

        String sql = "INSERT INTO students (first_name, last_name, username, dob, gender, email, number, password, program_id) "
                   + "VALUES (?,?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pst = con.prepareStatement(sql);
        
        pst.setString(1, firstName);
        pst.setString(2, lastName);
        pst.setString(3, username);
        pst.setDate(4, sqlDate);
        pst.setString(5, gender);
        pst.setString(6, email);
        pst.setString(7, number);
        pst.setString(8, password);
        pst.setInt(9, programId);

        pst.executeUpdate();
        pst.close();
        con.close();
    }

    public List<StudentModel> getAllStudents() throws Exception {
        List<StudentModel> students = new ArrayList<>();
        Connection con = DBconfig.getConnection();
        
        String sql = "SELECT * FROM students";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            StudentModel s = new StudentModel();
            s.setStudentId(rs.getInt("student_id")); // Mapping student_id
            s.setFirstName(rs.getString("first_name"));
            s.setLastName(rs.getString("last_name"));
            s.setUserName(rs.getString("username"));
            s.setDob(rs.getDate("dob")); 
            s.setEmail(rs.getString("email"));
            s.setNumber(rs.getString("number"));
            s.setProgram(rs.getInt("program_id"));
            students.add(s);
        }
        
        rs.close();
        pst.close();
        con.close();
        return students;
    }

    public StudentModel getStudentByUsername(String username) throws Exception {
        StudentModel student = null;
        Connection con = DBconfig.getConnection();
        
        String sql = "SELECT * FROM students WHERE username = ?";
        PreparedStatement pst = con.prepareStatement(sql);
        pst.setString(1, username);
        
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            student = new StudentModel();
            student.setStudentId(rs.getInt("student_id")); // Mapping student_id
            student.setFirstName(rs.getString("first_name"));
            student.setLastName(rs.getString("last_name"));
            student.setUserName(rs.getString("username"));
            student.setDob(rs.getDate("dob")); 
            student.setGender(rs.getString("gender"));
            student.setEmail(rs.getString("email"));
            student.setNumber(rs.getString("number"));
            student.setProgram(rs.getInt("program_id"));
            student.setPassword(rs.getString("password")); 
        }

        rs.close();
        pst.close();
        con.close();
        return student;
    }
    
    // Create a updateStudent method which takes id, firstname, lastname, dob, email and number as input and return rowsAffected
    
    }
