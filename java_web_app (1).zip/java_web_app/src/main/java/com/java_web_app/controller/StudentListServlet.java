package com.java_web_app.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

import com.java_web_app.model.StudentModel;
import com.java_web_app.service.ListService;

@WebServlet(asyncSupported = true, urlPatterns = { "/students" })
public class StudentListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public StudentListServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			ListService service = new ListService();
			
            // Get data from service
            List<StudentModel> students = service.fetchAll();

            // Set the data
            request.setAttribute("students", students);

            // Forward to JSP
            request.getRequestDispatcher("/WEB-INF/pages/student_list.jsp").forward(request, response);
            
        } catch (Exception e) {
            throw new ServletException("Database error", e);
        }
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
