package com.java_web_app.service;

import java.util.List;

import com.java_web_app.dao.StudentDAO;
import com.java_web_app.model.StudentModel;

public class ListService {
	public List<StudentModel> fetchAll() throws Exception {
		StudentDAO studentDAO = new StudentDAO();
        return studentDAO.getAllStudents();
    }
}
