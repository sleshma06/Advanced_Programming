package com.java_web_app.service;

import com.java_web_app.dao.StudentDAO;
import com.java_web_app.utils.PasswordUtil;

public class RegisterService {
	StudentDAO dao = new StudentDAO();

    public void addStudent(String firstName, String lastName, String username, String dob,
                           String gender, String email, String number, String password, int programId) throws Exception {
    	// For hashing password
    	password=PasswordUtil.getHashPassword(password); 
    	
        dao.insertStudent(firstName, lastName, username, dob, gender, email, number, password, programId);
    }
}