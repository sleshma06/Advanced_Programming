package com.java_web_app.service;

import com.java_web_app.dao.StudentDAO;
import com.java_web_app.model.StudentModel;
import com.java_web_app.utils.PasswordUtil;

public class LoginService {
	StudentDAO studentDAO = new StudentDAO();
	
    public String authenticate(String username, String password) {
    	
    	// Basic input fields validation
    	if (username == null || username.trim().isEmpty()) {
            return "Username is required";
        }
        if (password == null || password.isEmpty()) {
            return "Password is required";
        }
        
        // Actual logic to fetch student data and do validation
        try {
            // Fetch the student by username from DAO
            StudentModel student = studentDAO.getStudentByUsername(username);

            // Check if user exists
            if (student == null) {
                return "User doesn't exists";
            }

            // Verify the password using jBCrypt: BCrypt.checkpw(plain_text_password, hashed_password_from_db)
            if (PasswordUtil.checkPassword(password, student.getPassword())) {
                return "Success";
            } 
            else {
                return "Password is incorrect";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "Error in Database";
        }
    }
}